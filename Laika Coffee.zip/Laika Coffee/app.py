from flask import Flask, render_template, redirect, url_for, session, request

app = Flask(__name__)
app.secret_key = "laika_secret_key"

# Danh sách sản phẩm
products = [
    {"id": 1, "name": "Cà phê sữa đá", "description": "Cà phê nguyên chất pha với sữa đặc.", "price": 25000, "image": "static/images/caphesuada.jpg"},
    {"id": 2, "name": "Trà sữa trân châu", "description": "Trà sữa hương vị đặc biệt.", "price": 30000, "image": "static/images/trasuatranchauduongden.jpg"},
    {"id": 3, "name": "Latte đá", "description": "Cà phê Espresso pha với sữa tươi.", "price": 35000, "image": "static/images/latteda.jpg"},
    {"id": 4, "name": "Trà đào cam sả", "description": "Trà đào thơm ngon với cam sả.", "price": 40000, "image": "static/images/tradaocamsa.jpg"},
    {"id": 5, "name": "Trà kem dâu Đà Lạt", "description": "Trà kem dâu Đà Lạt thanh mát", "price": 55000, "image": "static/images/caphecotdua.jpg"},
    {"id": 6, "name": "Cà phê cốt dừa", "description": "Trà đào thơm ngon với cam sả.", "price": 50000, "image": "static/images/trakemdaudalat.jpg"}, 
]

# Trang chủ
@app.route("/")
def home():
    return render_template("home.html")

# Trang menu
@app.route("/menu")
def menu():
    return render_template("menu.html", products=products)

# Thêm sản phẩm vào giỏ hàng
@app.route("/add_to_cart/<int:product_id>")
def add_to_cart(product_id):
    cart = session.get("cart", [])
    for product in products:
        if product["id"] == product_id:
            # Kiểm tra nếu sản phẩm đã tồn tại trong giỏ hàng
            for item in cart:
                if item["id"] == product_id:
                    item["quantity"] += 1
                    break
            else:
                cart.append({"id": product["id"], "name": product["name"], "price": product["price"], "quantity": 1})
            break
    session["cart"] = cart
    return redirect(url_for("cart"))

# Trang giỏ hàng
@app.route("/cart")
def cart():
    cart = session.get("cart", [])
    total_price = sum(item["price"] * item["quantity"] for item in cart)
    return render_template("cart.html", cart=cart, total_price=total_price)

# Xóa sản phẩm khỏi giỏ hàng
@app.route("/remove_from_cart/<int:product_id>")
def remove_from_cart(product_id):
    cart = session.get("cart", [])
    cart = [item for item in cart if item["id"] != product_id]
    session["cart"] = cart
    return redirect(url_for("cart"))

# Xóa toàn bộ giỏ hàng
@app.route("/clear_cart")
def clear_cart():
    session.pop("cart", None)
    return redirect(url_for("cart"))

if __name__ == "__main__":
    app.run(debug=True)
